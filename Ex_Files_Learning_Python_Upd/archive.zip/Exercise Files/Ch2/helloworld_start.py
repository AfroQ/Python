# Example file for HelloWorld
print("Hello World!")
name = input("What is your name?")
print("Nice to meet you " + name)

def main():
    print("Hello World!")
    name = input("What is your name?")
    print("Nice to meet you " + name)
if __name__ == "_main_":
    main()
