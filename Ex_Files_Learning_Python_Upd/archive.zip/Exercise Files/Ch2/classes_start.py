#
# Example file for working with classes
class myClass():
    def method1(self):
        print("myClass method1")

    def method2(self, something):
        print("myClass method2 " + something)

class anotherClass(myClass): #inheriting from myClass
    def method1(self):
        myClass.method1(self) #Calling the inherited class
        print("anotherClass method1")

    def method2(self, something):
        print("anotherClass method2 ") #This will overwrite the existing method2

def main():
    c = myClass()
    c.method1()
    c.method2("This is a string")

    c2 = anotherClass()
    c2.method1()
    c2.method2("This is a string") #This argument will not be printed

if __name__ == "__main__":
    main()
